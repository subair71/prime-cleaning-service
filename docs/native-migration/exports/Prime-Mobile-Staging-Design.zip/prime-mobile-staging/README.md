# Prime Domestic mobile staging design

This package contains the ten saved staging page layouts and the native Fluent Forms export for the three-step mobile estimate. The mobile layouts apply through 767 CSS pixels. The site uses the original Prime crest, Kadence, GenerateBlocks, Fluent Forms Pro, the existing Google Reviews widgets and DS Mobile Menu.

## Restore on the existing staging site

1. In Fluent Forms, find **Prime | Mobile estimate**. The deployed form ID is 9. If it is missing, import `mobile-estimate.json` through Fluent Forms → Tools → Import Forms. WordPress assigns the new form an ID. If it differs from 9, use the block editor to update the mobile Prices shortcode and the form-specific selectors in that block.
2. With the existing form IDs and the preceding desktop design in place, extract this package outside the public web directory. Run `bash apply-staging.sh /absolute/path/to/staging your-wordpress-admin-login` from the extracted folder. The script verifies the site, form, and page revisions, then updates the ten pages in place. A second run recognises the installed version.
3. In the WordPress Customizer, select the phone preview. Open the menu, follow a service into Prices, and check a quote through the Enquiry step. For a standard, one-off, single-storey home in Malvern East with two bedrooms and two bathrooms, the range is A$190–A$230 before extras.

## Editor notes

- Home uses the existing quick estimator (form 8). Prices uses form 9 on phones and form 4 on larger screens. These two detailed forms have separate copies of the approved pricing fields and notifications. Apply future rate and notification changes to both, and update the Home quick estimator and synced starting prices where applicable.
- The detailed mobile form uses one bedrooms-and-bathrooms selector for each approved grid. Its estimate banner updates once the required property details and suburb establish a price. The Contact page uses the existing suburb picker to show the travel fee and form 3 for enquiries.
- The Terms layout is saved as a draft. The footer uses Prime’s published Terms. Privacy uses the full policy and Google reviews use the existing manual refresh setting.
- The export includes form settings. Customer submissions are stored separately in WordPress.
