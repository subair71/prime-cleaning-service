#!/usr/bin/env bash
set -euo pipefail

package_dir="$(cd "$(dirname "$0")" && pwd)"
if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo 'Usage: bash apply-staging.sh /path/to/staging [WordPress administrator login or ID]' >&2
  exit 2
fi
site=(wp "--path=$1")
if [[ $# == 2 ]]; then site+=("--user=$2"); fi
site_home="$("${site[@]}" option get home)"
if [[ "${site_home%/}" != 'https://primedomestic.com.au/staging' ]]; then
  echo "This package targets https://primedomestic.com.au/staging only." >&2
  exit 1
fi
table_prefix="$("${site[@]}" db prefix)"
[[ "$table_prefix" =~ ^[a-zA-Z0-9_]+$ ]] || exit 1
form_title="$("${site[@]}" db query "SELECT title FROM ${table_prefix}fluentform_forms WHERE id = 9" --skip-column-names)"
[[ "$form_title" == 'Prime | Mobile estimate' ]] || { echo 'Restore the native mobile estimator first. Read README.md for form IDs.' >&2; exit 1; }
# Resolve every destination and check its existing version before the first edit.
without_trailing_lines() { php -r 'echo hash("sha256",rtrim(str_replace("\r\n","\n",stream_get_contents(STDIN)),"\n"));'; }
while IFS=$'\t' read -r id slug filename old_hash new_hash; do
  [[ "$("${site[@]}" post get "$id" --field=post_type)" == page && "$("${site[@]}" post get "$id" --field=post_name)" == "$slug" ]] || { echo "Unexpected page at ID $id." >&2; exit 1; }
  current="$("${site[@]}" post get "$id" --field=post_content | without_trailing_lines)"
  [[ "$current" == "$old_hash" || "$current" == "$new_hash" ]] || { echo "The $slug page changed since export. Review that page before applying the package." >&2; exit 1; }
  [[ "$(without_trailing_lines < "$package_dir/pages/$filename")" == "$new_hash" ]] || { echo "Invalid package file $filename." >&2; exit 1; }
done < "$package_dir/pages.tsv"
while IFS=$'\t' read -r id slug filename old_hash new_hash; do
  current="$("${site[@]}" post get "$id" --field=post_content | without_trailing_lines)"
  if [[ "$current" != "$new_hash" ]]; then
    [[ "$current" == "$old_hash" ]] || { echo "Concurrent change detected on $slug." >&2; exit 1; }
    "${site[@]}" post update "$id" "$package_dir/pages/$filename"
    [[ "$("${site[@]}" post get "$id" --field=post_content | without_trailing_lines)" == "$new_hash" ]] || { echo "WordPress saved different content for $slug. Check the revision before continuing." >&2; exit 1; }
  fi
  # A page includes its own responsive header and footer.
  "${site[@]}" post meta update "$id" _kad_post_header 1
  "${site[@]}" post meta update "$id" _kad_post_footer 1
  "${site[@]}" post meta update "$id" _kad_post_title hide
  "${site[@]}" post meta update "$id" _kad_post_layout fullwidth
  "${site[@]}" post meta update "$id" _kad_post_content_style unboxed
  "${site[@]}" post meta update "$id" _kad_post_vertical_padding hide
done < "$package_dir/pages.tsv"
echo 'Updated the ten existing staging pages. Check Home, Prices and Contact in your browser.'
