# Prime Domestic staging design

The ten editable WordPress layouts follow the enhanced Prime Domestic prototype. Each header and the About page use the original round crest in the staging Media Library. The package targets the existing staging installation with GenerateBlocks, Kadence Blocks, Fluent Forms Pro and the existing Google Reviews widgets.

## Apply on staging

1. Extract this ZIP to a folder in the hosting account outside the public web directory.
2. In the hosting terminal, run `bash apply-staging.sh /absolute/path/to/staging your-wordpress-admin-login` from the extracted folder. Use the directory that contains the staging installation’s wp-config.php.
3. Open Home. Choose a service and rooms, check the AUD range, continue to Prices, and confirm the selections. Open Contact to check suburb fees. Review mobile navigation, review slides and the contact form.

The script uses WP-CLI and PHP CLI on the host. It updates the existing pages in place and checks their content against the staging export before editing. A second run recognises pages already updated. The Terms page keeps its existing publication status and the site links to the existing published Terms. WordPress revisions contain previous page content. The page layout settings in Kadence control the header, footer, title, width and padding.

An editor with dashboard access can also paste the corresponding file from `pages/` into an existing page’s WordPress code editor, then return to the visual editor and save. In Kadence Page Settings, choose Fullwidth and Unboxed, disable the theme header, footer and page title, and remove vertical content padding. Each file contains editable block markup.

## Content and forms

- Home uses Fluent Forms 8, Google review widgets 36 and 55, synced price patterns 38, 39 and 40, five visitor FAQs and a three-post query. The carousel uses the current plugin connection and manual refresh.
- Prices uses existing Fluent Form 4 and its approved rates and conditions. It keeps the current form sequence. The prototype’s three-step wizard is a visual difference.
- Contact uses existing Fluent Form 3 and a keyboard-accessible suburb selector. Choosing a listed suburb displays its travel zone.
- Home follows the supplied prototype’s text-only service cards. The supplied prototype and the approved job-photo policy omit a customer before-and-after gallery.
- Use WordPress to edit the full Privacy Policy. The short reference summary does not replace it.

The package contains page content and hosting commands. It requires no custom WordPress plugin or front-end script. It does not activate licenses, send forms or publish Terms.
